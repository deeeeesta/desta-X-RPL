public class operator6 {
    public static void main(String[] args) {
        int a = 10;
        int b = 8;
        int c = 6;
        int d = 15;

        System.out.println("nilai a: " + a++);
        System.out.println("nilai b: " + ++b);
        System.out.println("nilai c: " + c--);
        System.out.println("nilai d: " + --d);
    }
    
}
