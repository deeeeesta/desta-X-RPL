public class operator11 {
    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;

        System.out.println(!a); // !true --> output: false
        System.out.println(!b); // !false --> output: true

    }
}
