public class operator3 {
    public static void main(String[] args) {
        String nama1 = "Hummasoft";
        String nama2 = "Technology";

        String hasil = nama1 + nama2;
        System.out.println(hasil);
    }
}
