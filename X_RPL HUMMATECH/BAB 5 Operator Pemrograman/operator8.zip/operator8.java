public class operator8 {
    public static void main(String[] args) {
        
        // membandingkan huruf kapital
        char B = 'B';
        char Z = 'Z';
        char b = 'b';
        System.out.println("Apakah B > Z ? " + (B > Z));
        System.out.println("Apakah B < Z ? " + (B < Z));

        // membandingkan huruf kecil dengan huruf kapital
        System.out.println("Apakah b == B ? " + (b == B));
        System.out.println("Apakah b > B ? " + (b > B));
    }
    
}
